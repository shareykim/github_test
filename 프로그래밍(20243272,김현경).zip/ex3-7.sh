#!/bin/bash

folder_name="$HOME/$1"

if [ ! -d "$folder_name" ]; then
	mkdir "$folder_name"
fi

for i in {0..4}; do
	touch "$folder_name/file$i.txt"
done

for i in {0..4}; do
	subfolder="$folder_name/file$i"
	mkdir -p "$subfolder"
	ln -s "$folder_name/file$i.txt" "$subfolder/files$i.txt"
done
	
