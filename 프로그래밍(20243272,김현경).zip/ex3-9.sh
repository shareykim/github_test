#!/bin/bash

name=$1
grep -i "$name" DB.txt
