#!/bin/bash

echo "Is Linux fun? (yes/no)"
read answer

case $answer in
	[Yy]* )
		echo "yes"
		;;
	[Nn]* )
		echo "no"
		;;
	* )
		echo "answer as yes or no"
		;;
esac
