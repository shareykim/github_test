#!/bin/bash

folder_name="$HOME/$1"

if [ !  -d "$folder_name" ]; then
	mkdir "$folder_name"
fi

for i in {0..4}; do
	touch "$folder_name/file$i.txt"
done

tar -cvf "$folder_name/files.tar" -C "$folder_name" file0.txt file1.txt file2.txt file3.txt file4.txt
mkdir -p "$folder_name/extracted"
tar -xvf "$folder_name/files.tar" -C "$folder_name/extracted"
