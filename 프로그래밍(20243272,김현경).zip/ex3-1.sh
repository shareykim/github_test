#!/bin/bash

if [ -n "$1" ]; then
for ((i=0; i<$1;i++))
do 
echo "hello world"
done
else
while true
do
echo "hello world"
sleep 1
done
fi
