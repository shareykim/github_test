#!/bin/bash

name=$1
phone=$2

echo "$name $phone" >> DB.txt
