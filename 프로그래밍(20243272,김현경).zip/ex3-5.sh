#!/bin/bash

function run_ls() {
	echo "In the function"
	ls "$@"
	echo "Out the function"
}

echo "start the program"
run_ls "$@"
echo "end the program"
